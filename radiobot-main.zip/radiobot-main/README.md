# Radio-bot
# MADE BY DEVNEMIL
How to setup up video tutorial!

Link:- [TUTORIAL]()

# SUPPORT SERVER
LINK:- [Support Server]()

# HOW TO MAKE

1.) Rename .env-example to .env
2.) And fillout all details.
3.) dc_channel_id - Is the Id of voice channel.
4.) Link - is the link of live stream which will be played
5.) Token is bot token.
6.) Server Id - the server id in which the bot will play music.
